from django.shortcuts import render
from .models import *
from .forms import *
# Create your views here.
def display(request):
    details=notice.objects.all()
    content={'details':details}
    return render(request,'index.html',content)
def disp(request):
    return render(request,'new.html')
def vinay(request):
        return render(request,'user.html')

def my_notice_upload(request):
    forms=upload_forms()
    context={'forms':forms}
    return render(request,'upload.html',context)
