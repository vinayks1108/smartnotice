from django.db import models

# Create your models here.

class notice(models.Model):

    maincontent=models.CharField(max_length=20,verbose_name="Main content")
    headercontent=models.CharField(max_length=40,verbose_name="Header content")
    noticereference=models.CharField(max_length=20,verbose_name="Notice reference")
    noticetime=models.DateTimeField(null=True,auto_now_add=True,verbose_name="Notice Time")
    arrivaltime=models.DateTimeField(null=True,verbose_name="Arrival Time")
    noticeimage=models.ImageField(upload_to="static/upload",verbose_name="Upload Image")
    def __str__(self):
        return self.maincontent

class vinay(models.Model):
    username=models.CharField(max_length=20,verbose_name="User ID")
    password=models.CharField(max_length=10,verbose_name="Password")
    def __str__(self):
         return self.username
