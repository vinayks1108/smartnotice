from django.contrib import admin
from .models import notice
# Register your models here.

admin.site.register(notice)

