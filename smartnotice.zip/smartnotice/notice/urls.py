from django.urls import path , include
from .import views
from django.contrib.auth import views as auth_views

urlpatterns=[
    path('display/',views.display,name='display'),
    path('vs/',views.disp,name='disp'),
    path('my_notice_upload/',views.my_notice_upload,name='my_notice_upload')
]
